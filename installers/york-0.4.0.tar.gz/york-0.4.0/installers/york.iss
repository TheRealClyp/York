[Setup]
AppName=York
AppVersion=0.4.0
AppPublisher=York Contributors
AppCopyright=2026 York Contributors
DefaultDirName={userappdata}\Programs\york
DisableProgramGroupPage=yes
LicenseFile=..\LICENSE
OutputDir=.
OutputBaseFilename=york-setup-x64
SolidCompression=yes
Compression=lzma2/max
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayName=York 0.4.0
UninstallFilesDir={app}\uninstall

[Dirs]
Name: {app}\bin

[Files]
Source: ..\target\release\york.exe; DestDir: {app}\bin; DestName: york.exe; Flags: ignoreversion
Source: ..\LICENSE; DestDir: {app}; Flags: ignoreversion isreadme

[Run]
Filename: {cmd}; Parameters: "/c start """" ""https://york-lang.org"""; Flags: nowait postinstall skipifsilent unchecked; Description: "Open the York website"

[Code]
procedure CurStepChanged(CurStep: TSetupStep);
var
  Bin: string;
  OrigPath: string;
  NewPath: string;
begin
  if CurStep <> ssPostInstall then Exit;
  Bin := ExpandConstant('{app}\bin');
  if RegQueryStringValue(HKEY_CURRENT_USER, 'Environment', 'Path', OrigPath) then
  begin
    if Pos(LowerCase(Bin), LowerCase(';' + OrigPath + ';')) <> 0 then Exit;
    NewPath := OrigPath;
    if (Length(OrigPath) > 0) and (OrigPath[Length(OrigPath)] <> ';') then
      NewPath := NewPath + ';';
    NewPath := NewPath + Bin;
  end
  else
    NewPath := Bin;
  RegWriteExpandStringValue(HKEY_CURRENT_USER, 'Environment', 'Path', NewPath);
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  Bin: string;
  OrigPath: string;
  P: Integer;
begin
  if CurUninstallStep <> usPostUninstall then Exit;
  Bin := LowerCase(ExpandConstant('{app}\bin'));
  if not RegQueryStringValue(HKEY_CURRENT_USER, 'Environment', 'Path', OrigPath) then Exit;
  P := Pos(Bin, LowerCase(OrigPath));
  if P = 0 then Exit;
  Delete(OrigPath, P - 1 + Length(Bin) + 1, Length(Bin) + 1);
  if (Length(OrigPath) > 0) and (OrigPath[Length(OrigPath)] = ';') then
    SetLength(OrigPath, Length(OrigPath) - 1);
  RegWriteExpandStringValue(HKEY_CURRENT_USER, 'Environment', 'Path', OrigPath);
end;
